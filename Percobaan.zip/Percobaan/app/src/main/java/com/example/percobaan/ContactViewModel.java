package com.example.percobaan;

import android.app.Application;
import android.support.annotation.NonNull;

import java.util.List;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class ContactViewModel extends AndroidViewModel {
    private LiveData<List<Kontak>> allContacts = new MutableLiveData();
    private KontakRepository repository;
    public ContactViewModel(@NonNull Application application){
        super(application);
        repository = new KontakRepository();
        allContacts = repository.getAllContacts();
    }
    public LiveData<List<Kontak>> getListContact(){
        return allContacts;
    }
}
