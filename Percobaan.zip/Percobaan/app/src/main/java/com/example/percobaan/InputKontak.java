package com.example.percobaan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InputKontak extends AppCompatActivity {
    private TextView txtResult;
    private EditText txtInputNama,txtInputEmail,txtInputAlamat,txtInputNohp;
    KontakApi kontakApi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_kontak);
        txtResult = (TextView) findViewById(R.id.txtResult);
        txtInputNama = (EditText)findViewById(R.id.txtInputNama);
        txtInputEmail = (EditText)findViewById(R.id.txtInputEmail);
        txtInputNohp = (EditText)findViewById(R.id.txtInputNohp);
        txtInputAlamat = (EditText)findViewById(R.id.txtInputAlamat);

    }
    public void postContact(View v){
        String nama = txtInputNama.getText().toString();
        String email = txtInputEmail.getText().toString();
        String nohp = txtInputNohp.getText().toString();
        String alamat = txtInputAlamat.getText().toString();
        Kontak isi = new Kontak (nama,email,nohp,alamat);
        Call<Kontak> call = kontakApi.saveContact(isi);
        call.enqueue(new Callback<Kontak>() {
            @Override
            public void onResponse(Call<Kontak> call, Response<Kontak> response) {
                if(!response.isSuccessful()){
                    txtResult.setText("Code Response : "+response.code());
                    return;
                }
                Kontak kontak = response.body();
                String content = "";
                content+="ID    : "+kontak.getIdContact() + "\n";
                content+="Nama  : "+kontak.getName() + "\n";
                content+="Email : "+kontak.getEmail() + "\n";
                content+="No HP : "+kontak.getPhone() + "\n";
                content+="Alamat: "+kontak.getAddres() + "\n\n";
                txtResult.append(content);
            }


            @Override
            public void onFailure(Call<Kontak> call, Throwable t) {
                txtResult.setText(t.getMessage());
            }
        });
    }
}
