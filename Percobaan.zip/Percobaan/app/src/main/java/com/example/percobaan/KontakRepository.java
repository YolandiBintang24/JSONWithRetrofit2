package com.example.percobaan;

import android.util.Log;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class KontakRepository {
    Retrofit connection = ContactConnection.getInstance();
    private KontakApi kontakApi = connection.create(KontakApi.class);
    private MutableLiveData<List<Kontak>> allContacts = new MutableLiveData<>();

    public LiveData<List<Kontak>> getAllContacts(){
        Call<List<Kontak>> call = kontakApi.getAllContact();
        call.enqueue(new Callback<List<Kontak>>() {
            @Override
            public void onResponse(Call<List<Kontak>> call, Response<List<Kontak>> response) {
                allContacts.setValue(response.body());
            }

            @Override
            public void onFailure(Call<List<Kontak>> call, Throwable t) {
                Log.e("Err",t.getMessage());
            }
        });
        return allContacts;
    }
}
